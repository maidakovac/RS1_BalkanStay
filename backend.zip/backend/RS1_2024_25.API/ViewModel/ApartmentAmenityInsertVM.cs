﻿namespace RS1_2024_25.API.ViewModel
{
    public class ApartmentAmenityInsertVM
    {
        public int ApartmentId { get; set; }
        public int AmenityID { get; set; }
    }
}
