﻿namespace RS1_2024_25.API.ViewModel
{
    public class AmenityInsertVM
    {
        public string AmenityText { get; set; }
    }
}
