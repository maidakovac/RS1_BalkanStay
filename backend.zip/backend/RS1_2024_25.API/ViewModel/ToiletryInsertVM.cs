﻿namespace RS1_2024_25.API.ViewModel
{
    public class ToiletryInsertVM
    {
        public string Name { get; set; }
    }
}
