﻿namespace RS1_2024_25.API.ViewModel
{
    public class OwnerReviewInsertVM
    {
       
        public int AccountID { get; set; }
        public string Rating { get; set; }
    }
}
