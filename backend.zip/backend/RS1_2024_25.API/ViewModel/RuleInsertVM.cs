﻿namespace RS1_2024_25.API.ViewModel
{
    public class RuleInsertVM
    {

        public string RuleText { get; set; }
    }
}
