﻿namespace RS1_2024_25.API.ViewModel
{
    public class ToiletryUpdateVM
    {
        public int ToiletryID { get; set; }
        public string Name { get; set; }
    }
}
