﻿namespace RS1_2024_25.API.ViewModel
{
    public class ImageInsertVM
    {
        public byte[] Photo { get; set; }
    }
}
