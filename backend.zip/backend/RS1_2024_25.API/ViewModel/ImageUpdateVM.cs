﻿namespace RS1_2024_25.API.ViewModel
{
    public class ImageUpdateVM
    {
        public int ImageID { get; set; }
        public byte[] Photo { get; set; }
    }
}
