﻿namespace RS1_2024_25.API.ViewModel
{
    public class AmenityUpdateVM
    {
        public int AmenityID { get; set; }
        public string AmenityText { get; set; }
    }
}
