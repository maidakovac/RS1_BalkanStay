﻿namespace RS1_2024_25.API.ViewModel
{
    public class OwnerApartmentInsertVM
    {
        public int AccountID { get; set; }
        public int ApartmentId { get; set; }
    }
}
