﻿namespace RS1_2024_25.API.ViewModel
{
    public class ApartmentImageInsertVM
    {
        public int ApartmentId { get; set; }
        public int ImageID { get; set; }
    }
}
