﻿namespace RS1_2024_25.API.ViewModel
{
    public class ApartmentRuleInsertVM
    {
        public int ApartmentId { get; set; }

        public int RuleID { get; set; }
    }
}
