﻿namespace RS1_2024_25.API.ViewModel
{
    public class OwnerInsertVM
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }

    }
}
