﻿namespace RS1_2024_25.API.ViewModel
{
    public class ApartmentToiletryInsertVM
    {
        public int ApartmentId { get; set; }
        public int ToiletryID { get; set; }
    }
}
