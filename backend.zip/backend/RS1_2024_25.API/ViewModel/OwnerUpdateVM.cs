﻿namespace RS1_2024_25.API.ViewModel
{
    public class OwnerUpdateVM
    {
        public int AccountID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }

    }
}
