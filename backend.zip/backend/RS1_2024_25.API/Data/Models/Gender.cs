﻿namespace RS1_2024_25.API.Data.Models
{
    public class Gender
    {
        public int GenderID { get; set; }
        public string Name { get; set; }
    }
}
