﻿namespace RS1_2024_25.API.Data.Models.Auth
{
    public class Administrator:Account
    {
        
    }
}
